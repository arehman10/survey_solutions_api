SUSO - Survey Solutions REST API client for Stata
Update to the existing SSC package: version 1.7.42, 3 October 2026
Backend: 1.7.40-ZIPPASSWORD

Author: Attique Ur Rehman
Affiliation: The World Bank, Development Economics, Enterprise Surveys
Contact: attique@worldbank.org
License: MIT; see LICENSE.

Please update the existing suso package on SSC with these revised files.

Files supplied
--------------
suso.ado       Stata command
suso.sthlp     Stata help
suso.jar       Compiled Java backend, required at runtime
suso.pkg       Package description and installation file list
stata.toc      Local package index
LICENSE        License terms
SSC_README.txt This submission and installation note

Only suso.ado, suso.sthlp and suso.jar are installed by suso.pkg. The JAR
contains production classes only. No tests, logs, survey data, credentials,
Java source, build tools or review materials are included in this ZIP.

Requirements
------------
The command declares Stata 14.2 language compatibility and requires Java 11
or newer. Local verification used Windows StataNow/MP 19.5 with Java 21;
older Stata versions and other operating systems were not newly tested.

Users should restart Stata after updating, so it loads the current files.
The diagnostic command suso doctor, strict should report ADO
1.7.42-RESTARTQC and compatible backend 1.7.40-ZIPPASSWORD.

Update description
------------------
This frontend update corrects paradata timing and review signals:

- A tablet event recorded with UTC offset 00:00:00 between the same
  interviewer's events at the device offset (seen on Restarted) keeps its
  UTC time; its device-local time now uses the neighbouring offset. The
  event history no longer shows a false offset change or a backwards
  local clock, and local dates and work-day counts are corrected.
- When an interviewer completes an interview and restarts it on the
  tablet before any supervisor or headquarters action, the work after
  the restart now counts as first-pass work for the short-interview,
  speed, night, duration, question-order and start-date checks. The
  restart stays visible as a Watch note that separates changed values,
  first-time answers, identical re-entries and removals.
- Exactly five minutes of work is no longer reported as short because of
  floating-point rounding. Missing interviewer timestamps, completed
  interviews without answers in CAWI or unknown mode, and durations that
  cannot be measured no longer receive a short-interview flag.
- Question-order review no longer flags edits of preloaded answers or
  answers tied in time with an untimed row, finds deviations hidden by a
  repeated roster question, and no longer depends on where an interview
  sits in the export when some event orders are missing.

Existing HTML reports and suites must be regenerated to receive the changes.

The compiled Java backend is unchanged from version 1.7.40. Its password
preservation and encrypted-header compatibility fixes remain included.

Stata expands macros before calling an ado command. When typing a literal
dollar sign in a password, prefix it with one backslash; quotes alone do
not prevent expansion. For example, the invented password qa$QA_LITERAL
must be supplied as unzipw("qa\$QA_LITERAL"). Apply the same rule to
exportpw(). This input escape is not added to the password received by
the command. See help suso for the related backtick guidance.
