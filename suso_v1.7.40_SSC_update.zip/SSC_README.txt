SUSO - Survey Solutions REST API client for Stata
Update to the existing SSC package: version 1.7.40, 30 September 2026
Backend: 1.7.40-ZIPPASSWORD

Author: Attique Ur Rehman
Affiliation: The World Bank, Development Economics, Enterprise Surveys
Contact: attique@worldbank.org
License: MIT; see LICENSE.

Please update the existing suso package on SSC with these revised files.

Files supplied
--------------
suso.ado       Stata command
suso.sthlp     Stata help
suso.jar       Compiled Java backend, required at runtime
suso.pkg       Package description and installation file list
stata.toc      Local package index
LICENSE        License terms
SSC_README.txt This submission and installation note

Only suso.ado, suso.sthlp and suso.jar are installed by suso.pkg. The JAR
contains production classes only. No tests, logs, survey data, credentials,
Java source, build tools or review materials are included in this ZIP.

Requirements
------------
The command declares Stata 14.2 language compatibility and requires Java 11
or newer. Local verification used Windows StataNow/MP 19.5 with Java 21;
older Stata versions and other operating systems were not newly tested.

Users should restart Stata after updating, so it loads the new backend.
The diagnostic command suso doctor, strict should report backend
1.7.40-ZIPPASSWORD.

Update description
------------------
This release preserves ZIP passwords across internal Stata option/macro
forwarding and accepts compatible traditional ZIP encryption header
conventions while retaining full-file validation before publication.
The included help explains literal-character input and local extraction.

Stata expands macros before calling an ado command. When typing a literal
dollar sign in a password, prefix it with one backslash; quotes alone do
not prevent expansion. For example, the invented password qa$QA_LITERAL
must be supplied as unzipw("qa\$QA_LITERAL"). Apply the same rule to
exportpw(). This input escape is not added to the password received by
the command. See help suso for the related backtick guidance.
